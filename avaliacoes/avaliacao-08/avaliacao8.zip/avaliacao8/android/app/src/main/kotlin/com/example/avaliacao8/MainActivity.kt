package com.example.avaliacao8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
